<?php

use Illuminate\Database\Capsule\Manager as Capsule;

class Kashier
{

    /**
     * @return string
     */
    public function getPaymentMethods($card, $installments, $wallet, $fawry)
    {
        $methods = array();

        if ($card) {
            $methods[] = 'card';
        }

        if ($installments) {
            $methods[] = 'bank_installments';
        }

        if ($wallet) {
            $methods[] = 'wallet';
        }

        if ($fawry) {
            $methods[] = 'fawry';
        }

        return implode(',', $methods);
    }


    /**
     * @param string $str
     * @return mixed
     */
    public static function  encode_urlComponent($str) {
        $revert = array('%21'=>'!', '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')');
        return strtr(rawurlencode($str), $revert);
    }

    /**
     * @param string $secretKey
     * @param string $data
     * @return mixed
     */
    public function createHash($secret, $data)
    {
            $amount = $data['amount'];
            $currency = $data['currency'];
            $orderId = $data["order_id"];
            $mid = $data['merchant_id'];
            $path = "/?payment=".$mid.".".$orderId.".".$amount.".".$currency;
            $hash = hash_hmac( 'sha256' , $path , $secret ,false);
            return $hash;
    }    

    /**
     * @param string $payload
     * @param string $secret
     * @return mixed
     */
    public function createSignature($payload, $secret)
    {
        return hash_hmac('sha256',$payload, $secret, false);
    }    



    /**
     * @param array $params
     * @return array
     */
    public function getData($params)
    {
        $reference_prefix = 'WH-'.date('Ymd', time()) . '-';
 
        $order_id = $reference_prefix . $params['invoiceid'];
        
        $hash = $this->createHash( $params['api_key'], ['order_id' => $order_id,
                                   'merchant_id' => $params['merchant_id'],
                                   'currency' => $params['currency'],
                                   'amount' => $params['amount'] ]);

        $returnedData = [
            "currency" => $params['currency'],
            "amount" => $params['amount'],
            'meta_data' => json_encode([
                'userName' => $params['clientdetails']['firstname'] . ' ' . $params['clientdetails']['lastname'],
                'userMobile' => $params['clientdetails']['phonenumber'],
                'userEmail' => $params['clientdetails']['email'],
                'ecommercePlatform' => 'whmcs'
            ]),
            'callback_url'=> $params['systemurl'] . '/modules/gateways/callback/kashier.php',
            'method' => $this->getPaymentMethods($params['isCardActivated'], $params['isInstallmentsActivated'], $params['isWalletActivated'], $params['isFawryActivated']),
            "order_id" => $order_id,
            'return_url'=> $params['systemurl'] . '/viewinvoice.php?id=' . $params['invoiceid'],
            'hash' => $hash
        ];

        return $returnedData;
    }

    /**
     * @return array
     */
    public function getConfig()
    {
        return array(
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'Kashier Payments',
            ),
            'admin_username' => array(
                'FriendlyName' => 'Admin UserName',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'The admin user of WHMCS background which has permission to modify the order status. If you do not fill it in, you will need to manually modify the order status after payment is completed.'
            ),
            // a text field type allows for single line text input
            'merchant_id' => array(
                'FriendlyName' => 'Merchant ID',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your Merchant ID here'
            ),
            'api_key' => array(
                'FriendlyName' => 'Payment API Key',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your Payment API Key here'
            ),
            'isCardActivated' => array(
                'FriendlyName' => 'Tick to enable CARD payment method',
                'Type' => 'yesno'
            ),
            'isInstallmentsActivated' => array(
                'FriendlyName' => 'Tick to enable INSTALLMENTS payment method',
                'Type' => 'yesno'
            ),
            'isWalletActivated' => array(
                'FriendlyName' => 'Tick to enable WALLET payment method',
                'Type' => 'yesno'
            ),
            'isFawryActivated' => array(
                'FriendlyName' => 'Tick to enable FAWRY payment method',
                'Type' => 'yesno'
            ),
            'test_mode' => array(
                'FriendlyName' => 'Payments Mode',
                'Type' => 'radio',
                'Options' => 'live,test',
                'Description' => 'Choose payment mode',
            ),
        );
    }

}