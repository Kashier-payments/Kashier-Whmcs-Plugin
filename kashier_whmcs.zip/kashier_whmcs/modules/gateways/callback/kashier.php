<?php

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
require_once __DIR__ . '/../../../modules/gateways/kashier/Kashier.php';

use Illuminate\Database\Capsule\Manager as Capsule;


$gatewayModuleName = basename(__FILE__, '.php');


$gatewayParams = getGatewayVariables($gatewayModuleName);


if (!$gatewayParams['type']) {
    die("Module Not Activated");
}


logTransaction($gatewayParams['name'], $_POST, 'kashier callback');

$headers = getallheaders();

$headers = array_change_key_case($headers);

$json = json_decode(file_get_contents('php://input'), true);

if (empty($json) || !isset($json['data']) || $json['event'] != 'pay') {
    echo 'input is null';
    exit;
}

$data = $json['data'];
if(!isset($data['merchantOrderId']) ||!isset($data['transactionId'])){
    return false;
}

/**
 * Validate Callback Invoice ID.
 *
 * Checks invoice ID is a valid invoice number. Note it will count an
 * invoice in any status as valid.
 *
 * Performs a die upon encountering an invalid Invoice ID.
 *
 * Returns a normalised invoice ID.
 *
 * @param int $invoiceId Invoice ID
 * @param string $gatewayName Gateway Name
 */
$invoiceId = substr($data['merchantOrderId'], 12);
$invoiceId = checkCbInvoiceID($invoiceId, $gatewayParams['name']);

$orderid = Capsule::table('tblorders')->where('invoiceid',$invoiceId)->value('id');

$kashier = new Kashier();

$dataToHash = [];
        
foreach ($data['signatureKeys'] as $key) {
    $dataToHash[$key] = $data[$key];
}

$queryString = http_build_query($dataToHash, $numeric_prefix = "", $arg_separator = '&', $encoding_type = PHP_QUERY_RFC3986);

$auth = $kashier->createSignature($queryString, $gatewayParams['api_key']);

logTransaction($gatewayParams['name'], $queryString, 'Kashier notify query signature:');
logTransaction($gatewayParams['name'], $auth, 'Kashier notify signature:');

if ($headers['x-kashier-signature'] == $auth) {
    logTransaction($gatewayParams['name'], '', 'Kashier notify verify signature success');
    try{
        $order_status = 'P';
        if ($data['status'] == 'SUCCESS') {
            /**
             * Add Invoice Payment.
             *
             * Applies a payment transaction entry to the given invoice ID.
             *
             * @param int $invoiceId         Invoice ID
             * @param string $transactionId  Transaction ID
             * @param float $paymentAmount   Amount paid (defaults to full balance)
             * @param float $paymentFee      Payment fee (optional)
             * @param string $gatewayModule  Gateway module name
             */
            addInvoicePayment(
                $invoiceId,
                $data['transactionId'],
                0,
                0,
                $gatewayModuleName
            );
            //accept order
            $command = 'AcceptOrder';
            $postData = array(
                'orderid' => $orderid,
                'autosetup' => true,
            );
            $adminUsername = $gatewayParams['admin_username']; // Optional for WHMCS 7.2 and later

            $results = localAPI($command, $postData, $adminUsername);
            logTransaction($gatewayParams['name'], $results, 'Kashier notify update order id is ' . $orderid);
        } else {
            //cancel order
            $command = 'CancelOrder';
            $postData = array(
                'orderid' => $orderid,
            );
            $adminUsername = $gatewayParams['admin_username']; // Optional for WHMCS 7.2 and later

            $results = localAPI($command, $postData, $adminUsername);
            logTransaction($gatewayParams['name'], $results, 'Kashier notify cancel order id is ' . $orderid);
            /**
             * Reverse a payment.
             *
             * @param string $reverseTransactionId
             * @param string $originalTransactionId
             *
             * @throws Exception
             */
            try {
                $reverseTransactionId = $data['transactionId'];
                $originalTransactionId = $data['transactionId'];
                paymentReversed($reverseTransactionId, $originalTransactionId);
            } catch (\Exception $e) {
                $errorMessage = $e->getMessage();
                logTransaction($gatewayParams['name'], $errorMessage, 'Kashier notify paymentReversed is error');
            }
        }
        $params = array(
            'action' => 'success',
        );
        ob_clean();
        print json_encode($params);
        exit;
    }catch(\Exception $e){
        $params = array(
            'action'=>'fail',
            'err_code'=>$e->getCode(),
            'err_msg'=>$e->getMessage()
        );
        ob_clean();
        print json_encode($params);
        exit;
    }
}else{
    logTransaction($gatewayParams['name'], '', 'Kashier notify verify signature fail');
}
return false;