<?php
/**
 * WHMCS Sample Payment Callback File
 *
 * This sample file demonstrates how a payment gateway callback should be
 * handled within WHMCS.
 *
 * It demonstrates verifying that the payment gateway module is active,
 * validating an Invoice ID, checking for the existence of a Transaction ID,
 * Logging the Transaction for debugging and Adding Payment to an Invoice.
 *
 * For more information, please refer to the online documentation.
 *
 * @see https://developers.whmcs.com/payment-gateways/callbacks/
 *
 * @copyright Copyright (c) WHMCS Limited 2017
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */

// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
require_once __DIR__ . '/../../../modules/gateways/kashier/Kashier.php';

use Illuminate\Database\Capsule\Manager as Capsule;

// Detect module name from filename.
$gatewayModuleName = basename(__FILE__, '.php');

// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);

// Die if module is not active.
if (!$gatewayParams['type']) {
    die("Module Not Activated");
}

// log
logTransaction($gatewayParams['name'], $_POST, 'kashier_card callback');

$headers = getallheaders();
// Lower case all keys
$headers = array_change_key_case($headers);

$json = json_decode(file_get_contents('php://input'), true);

if (empty($json) || !isset($json['data']) || $json['event'] != 'pay') {
    echo 'input is null';
    exit;
}

$data = $json['data'];
if(!isset($data['merchantOrderId']) ||!isset($data['transactionId'])){
    return false;
}

/**
 * Validate Callback Invoice ID.
 *
 * Checks invoice ID is a valid invoice number. Note it will count an
 * invoice in any status as valid.
 *
 * Performs a die upon encountering an invalid Invoice ID.
 *
 * Returns a normalised invoice ID.
 *
 * @param int $invoiceId Invoice ID
 * @param string $gatewayName Gateway Name
 */
$invoiceId = substr($data['merchantOrderId'], 12);
$invoiceId = checkCbInvoiceID($invoiceId, $gatewayParams['name']);

$orderid = Capsule::table('tblorders')->where('invoiceid',$invoiceId)->value('id');

$kashier = new Kashier();

$dataToHash = [];
        
foreach ($data['signatureKeys'] as $key) {
    $dataToHash[$key] = $data[$key];
}

$queryString = http_build_query($dataToHash, $numeric_prefix = "", $arg_separator = '&', $encoding_type = PHP_QUERY_RFC3986);

$auth = $kashier->createSignature($queryString, $gatewayParams['api_key']);

logTransaction($gatewayParams['name'], $queryString, 'Kashier notify query signature:');
logTransaction($gatewayParams['name'], $auth, 'Kashier notify signature:');

if ($headers['x-kashier-signature'] == $auth) {
    logTransaction($gatewayParams['name'], '', 'Kashier notify verify signature success');
    try{
        $order_status = 'P';
        if ($data['status'] == 'SUCCESS') {
            /**
             * Add Invoice Payment.
             *
             * Applies a payment transaction entry to the given invoice ID.
             *
             * @param int $invoiceId         Invoice ID
             * @param string $transactionId  Transaction ID
             * @param float $paymentAmount   Amount paid (defaults to full balance)
             * @param float $paymentFee      Payment fee (optional)
             * @param string $gatewayModule  Gateway module name
             */
            addInvoicePayment(
                $invoiceId,
                $data['transactionId'],
                0,
                0,
                $gatewayModuleName
            );
            //accept order
            $command = 'AcceptOrder';
            $postData = array(
                'orderid' => $orderid,
                'autosetup' => true,
            );
            $adminUsername = $gatewayParams['admin_username']; // Optional for WHMCS 7.2 and later

            $results = localAPI($command, $postData, $adminUsername);
            logTransaction($gatewayParams['name'], $results, 'Kashier notify update order id is ' . $orderid);
        } else {
            //cancel order
            $command = 'CancelOrder';
            $postData = array(
                'orderid' => $orderid,
            );
            $adminUsername = $gatewayParams['admin_username']; // Optional for WHMCS 7.2 and later

            $results = localAPI($command, $postData, $adminUsername);
            logTransaction($gatewayParams['name'], $results, 'Kashier notify cancel order id is ' . $orderid);
            /**
             * Reverse a payment.
             *
             * @param string $reverseTransactionId
             * @param string $originalTransactionId
             *
             * @throws Exception
             */
            try {
                $reverseTransactionId = $data['transactionId'];
                $originalTransactionId = $data['transactionId'];
                paymentReversed($reverseTransactionId, $originalTransactionId);
            } catch (\Exception $e) {
                // Transaction could not be found or already reversed
                $errorMessage = $e->getMessage();
                logTransaction($gatewayParams['name'], $errorMessage, 'Kashier notify paymentReversed is error');
            }
        }
        $params = array(
            'action' => 'success',
        );
        ob_clean();
        print json_encode($params);
        exit;
    }catch(\Exception $e){
        $params = array(
            'action'=>'fail',
            'err_code'=>$e->getCode(),
            'err_msg'=>$e->getMessage()
        );
        ob_clean();
        print json_encode($params);
        exit;
    }
}else{
    logTransaction($gatewayParams['name'], '', 'Kashier notify verify signature fail');
}
return false;